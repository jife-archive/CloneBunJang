//
//  TagCollectionViewCell.swift
//  BunJang
//
//  Created by 최지철 on 2023/03/09.
//

import UIKit

class TagCollectionViewCell: UICollectionViewCell {

    @IBOutlet weak var tagLabel: UILabel!
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

}
