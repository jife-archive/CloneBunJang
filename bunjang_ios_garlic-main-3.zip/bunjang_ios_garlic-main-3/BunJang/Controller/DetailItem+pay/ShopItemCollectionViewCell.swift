//
//  ShopItemCollectionViewCell.swift
//  BunJang
//
//  Created by 최지철 on 2023/03/10.
//

import UIKit

class ShopItemCollectionViewCell: UICollectionViewCell {

    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

}
