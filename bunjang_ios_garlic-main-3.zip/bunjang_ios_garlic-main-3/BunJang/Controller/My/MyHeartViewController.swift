//
//  MyHeartViewController.swift
//  BunJang
//
//  Created by 최지철 on 2023/03/12.
//

import UIKit

class MyHeartViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()

    }
    


}
