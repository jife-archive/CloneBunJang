//
//  TabBar.swift
//  BunJang
//
//  Created by 최지철 on 2023/03/08.
//

import UIKit

class TabBar: UITabBar {

    /*
    // Only override draw() if you perform custom drawing.
    // An empty implementation adversely affects performance during animation.
    override func draw(_ rect: CGRect) {
        // Drawing code
    }
    */

}
