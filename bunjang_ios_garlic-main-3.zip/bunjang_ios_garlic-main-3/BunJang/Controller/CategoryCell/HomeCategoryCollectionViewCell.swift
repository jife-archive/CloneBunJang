//
//  HomeCategoryCollectionViewCell.swift
//  BunJang
//
//  Created by 최지철 on 2023/03/05.
//

import UIKit

class HomeCategoryCollectionViewCell: UICollectionViewCell {

    @IBOutlet weak var label: UILabel!
    @IBOutlet weak var img: UIImageView!
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

}
