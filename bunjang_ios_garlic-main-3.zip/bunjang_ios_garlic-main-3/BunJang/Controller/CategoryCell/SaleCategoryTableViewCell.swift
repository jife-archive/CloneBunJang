//
//  SaleCategoryTableViewCell.swift
//  BunJang
//
//  Created by 최지철 on 2023/03/08.
//

import UIKit

class SaleCategoryTableViewCell: UITableViewCell {

    @IBOutlet weak var CategoryLabel: UILabel!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    
}
