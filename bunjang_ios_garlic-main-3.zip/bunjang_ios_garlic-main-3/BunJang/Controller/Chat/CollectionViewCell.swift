//
//  CollectionViewCell.swift
//  BunJang
//
//  Created by 최지철 on 2023/03/13.
//

import UIKit

class CollectionViewCell: UICollectionViewCell {

    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

}
