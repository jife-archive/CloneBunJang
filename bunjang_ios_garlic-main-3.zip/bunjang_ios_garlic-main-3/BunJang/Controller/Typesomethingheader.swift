//
//  Typesomethingheader.swift
//  BunJang
//
//  Created by 최지철 on 2023/03/15.
//

import UIKit

class Typesomethingheader: UICollectionReusableView {
        
}
