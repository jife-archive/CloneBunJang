//
//  ViewController.swift
//  BunJang
//
//  Created by 최지철 on 2023/03/04.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }


}

