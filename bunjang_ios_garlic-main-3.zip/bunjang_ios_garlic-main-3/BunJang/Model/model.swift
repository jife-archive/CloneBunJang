//
//  model.swift
//  BunJang
//
//  Created by 최지철 on 2023/03/04.
//

import Foundation
struct saleInfo {
    var Category: String
    var ItemName: String
    var Price: String
    var option: String
}

class saleData{
    static let shared = saleData()
    
    
}


class reascherData {
    static let shared = reascherData()
    
   public var recentSearchList: [String] = []
    
    var fresearchData = [
    fresearch(Name: "레드벨벳"),
    fresearch(Name: "미닛뮤트"),
    fresearch(Name: "찌청명"),
    fresearch(Name: "스투시 후드집업"),
    fresearch(Name: "오지타"),
    fresearch(Name: "보스 qc45"),
    fresearch(Name: "와코마리아"),
    fresearch(Name: "베트멍"),
    fresearch(Name: "에어팟 프로 미개봉"),
    fresearch(Name: "리오버"),
    ]
    
}
